#pragma once

#include "gameconfig.h"

bool InitPatches(CGameConfig *gameConfig);
void UndoPatches();
